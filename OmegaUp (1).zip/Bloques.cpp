#include <iostream>

using namespace std;

int main(){
	char table[100];

	


	return 0;
}