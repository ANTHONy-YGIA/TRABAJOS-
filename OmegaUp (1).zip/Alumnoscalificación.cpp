#include <iostream>

using namespace std;

int main(){
	int r0, r1, r2;

	cin >> r0;
	cin >> r1;
	cin >> r2;

	cout << r0 * 0.6 + r1 * 0.2 + r2 * 0.2;

}