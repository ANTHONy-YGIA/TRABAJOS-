#include <iostream>

using namespace std;

int main(){
	int r0;

	cin >> r0;

	for ( int n = 0; n < r0; n++ ){
		cout << "Bienvenido a C++ ";

	}

	return 0;
}