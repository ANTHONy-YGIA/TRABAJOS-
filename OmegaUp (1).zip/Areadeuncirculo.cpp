#include <iostream>

using namespace std;

int main(){
	int r0;

	cin >> r0;

	cout << 3.1416 * r0 * r0;


	return 0;
}