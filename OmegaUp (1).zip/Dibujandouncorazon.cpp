#include <iostream>

using namespace std;

int main(){
	char v = 'c';
	cout <<	   FFFFFF      FFFFF
			  FFFFFFFF    FFFFFFF
			 FFFFFFFFFF  FFFFFFFFF
			FFFFFFFFFFFFFFFFFFFFFFF
			FFFFFFFFFFFFFFFFFFFFFFF
			 FFFFFFFFFFFFFFFFFFFFF
			  FFFFFFFFFFFFFFFFFFF
			   FFFFFFFFFFFFFFFFF
			    FFFFFFFFFFFFFFF
			     FFFFFFFFFFFFF
			      FFFFFFFFFFF
			       FFFFFFFFF
			        FFFFFFF
			         FFFFF
			          FFF
			           F



	return 0
}