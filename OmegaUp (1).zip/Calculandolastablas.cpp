#include <iostream>

int main(){
  int r0;
  std::cin >> r0;
  
  
  for ( int n = 0; n < 11; n++  ){
    std::cout << r0 * n << ' ';
    
  }
  
  
  return 0;
}