#include <iostream>

using namespace std;

int main(){
	int r0, r1;
	float r2 = 0;


	cin >> r0;
	cin >> r1;


	r2 = (r0 + r1);


  cout << r2 / 2;


	return 0;
}