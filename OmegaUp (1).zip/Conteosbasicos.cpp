#include<bits/stdc++.h>

using namespace std;

int main() {

    int from, to;
    scanf("%d %d\n", &from, &to);
    
    for (int i = from; i <= to; i++)
        printf("%d\n", i);

    return 0;
}