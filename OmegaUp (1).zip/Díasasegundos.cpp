#include <iostream>

using namespace std;

int main(){
	int r0;

	cin >> r0;

	cout << r0 * 86400;



	return 0;
}