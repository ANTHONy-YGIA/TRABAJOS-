#include <iostream>

using namespace std;

int main(){
	int r0, r1;

	cin >> r0;
	cin >> r1;

	cout << r0 + r



	return 0;
}